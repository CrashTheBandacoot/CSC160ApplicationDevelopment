﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2DGameLibrary
{
    public class Game //: _2DGameLibrary.Playable
    {
        public void GameLoop()
        {
            //TakeTurn(activePlayer);
            ////select the other player
            //indexOfCurrentPlayer = (indexOfCurrentPlayer == 0) ? 1 : 0;
            //activePlayer = players[indexOfCurrentPlayer];
        }

        //public void TakeTurn(Player activePlayer)
        //{
            
        //}
    }
}
